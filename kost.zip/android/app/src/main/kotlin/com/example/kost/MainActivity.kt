package com.example.kost

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
