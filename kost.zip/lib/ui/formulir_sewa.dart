import 'package:flutter/material.dart';
import '../model/kost.dart'; // Sesuaikan dengan struktur projek Anda
import 'package:kost/ui/payment_method.dart'; // Sesuaikan dengan lokasi halaman pembayaran

class FormulirSewa extends StatefulWidget {
  final Kost kost;

  const FormulirSewa({Key? key, required this.kost}) : super(key: key);

  @override
  _FormulirSewaState createState() => _FormulirSewaState();
}

class _FormulirSewaState extends State<FormulirSewa> {
  TextEditingController _namaController = TextEditingController();
  TextEditingController _kontakController = TextEditingController();
  TextEditingController _tanggalMasukController = TextEditingController();
  TextEditingController _tanggalKeluarController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Formulir Sewa ${widget.kost.namaKost}"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextFormField(
              controller: _namaController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            TextFormField(
              controller: _kontakController,
              decoration: InputDecoration(labelText: 'Kontak'),
            ),
            TextFormField(
              controller: _tanggalMasukController,
              decoration: InputDecoration(labelText: 'Tanggal Masuk'),
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(DateTime.now().year + 1),
                );
                if (pickedDate != null) {
                  setState(() {
                    _tanggalMasukController.text =
                        "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
                  });
                }
              },
            ),
            TextFormField(
              controller: _tanggalKeluarController,
              decoration: InputDecoration(labelText: 'Tanggal Keluar'),
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(DateTime.now().year + 1),
                );
                if (pickedDate != null) {
                  setState(() {
                    _tanggalKeluarController.text =
                        "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
                  });
                }
              },
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PaymentMethod(kost: widget.kost),
                    ),
                  );
                },
                child: Text("Submit"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
