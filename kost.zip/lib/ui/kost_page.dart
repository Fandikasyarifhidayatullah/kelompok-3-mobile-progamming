import 'package:flutter/material.dart';
import 'package:kost/ui/detail_kost.dart'; // Sesuaikan dengan path yang benar
import '../model/kost.dart'; // Sesuaikan dengan path yang benar

class KostPage extends StatelessWidget {
  const KostPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Ganti dengan logika pengambilan data kost sesuai kebutuhan
    List<Kost> listKost = [
      Kost(
          id: "1",
          namaKost: "Kost Avenged",
          lokasi: "Ciputat",
          harga: 1500000,
          fasilitas: ["Wi-Fi", "AC", "Kamar Mandi Dalam"]),
      Kost(
          id: "3",
          namaKost: "Kost Nightmare",
          lokasi: "Ciputat",
          harga: 1000000,
          fasilitas: ["Wi-Fi", "AC"]),
      Kost(
          id: "4",
          namaKost: "Kost Murim",
          lokasi: "Ciputat",
          harga: 1600000,
          fasilitas: ["Wi-Fi", "AC", "Kamar Mandi Dalam", "Meja"]),
      Kost(
          id: "5",
          namaKost: "Kost Magenta",
          lokasi: "Ciputat",
          harga: 1500000,
          fasilitas: ["Wi-Fi", "AC", "Kamar Mandi Dalam", "Meja"]),
      Kost(
          id: "6",
          namaKost: "Kost Ryussen",
          lokasi: "Ciputat",
          harga: 1700000,
          fasilitas: ["Wi-Fi", "AC", "Kamar Mandi Dalam", "Meja", "Lemari"]),
      Kost(
          id: "7",
          namaKost: "Kost Rege",
          lokasi: "Ciputat",
          harga: 1400000,
          fasilitas: ["Wi-Fi", "AC", "Kamar Mandi Dalam", "Meja"]),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Daftar Kost")),
      body: ListView.builder(
        itemCount: listKost.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(listKost[index].namaKost),
              subtitle: Text(
                  "Lokasi: ${listKost[index].lokasi}\nHarga: Rp ${listKost[index].harga.toStringAsFixed(2)}"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => KostDetail(kost: listKost[index]),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
