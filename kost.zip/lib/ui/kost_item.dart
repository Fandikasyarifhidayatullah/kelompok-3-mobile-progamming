import 'package:flutter/material.dart';
import '../model/kost.dart';

class KostItem extends StatelessWidget {
  final Kost kost;
  final Function(Kost) onUpdate;
  final Function(Kost) onDelete;

  const KostItem({
    Key? key,
    required this.kost,
    required this.onUpdate,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(kost.namaKost),
      subtitle: Text(kost.lokasi),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              // Logic for updating kost
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () {
              onDelete(kost);
            },
          ),
        ],
      ),
    );
  }
}
