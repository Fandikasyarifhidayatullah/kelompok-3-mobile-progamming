import 'package:flutter/material.dart';
import '../model/kost.dart'; // Pastikan import ini sesuai dengan struktur projek Anda

class PaymentConfirmation extends StatelessWidget {
  final Kost kost;
  final String method;
  final String nomorPemilik;

  const PaymentConfirmation({
    Key? key,
    required this.kost,
    required this.method,
    required this.nomorPemilik,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Konfirmasi Pembayaran"),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Metode Pembayaran: $method",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              "Nomor Rekening/Dompet Digital: $nomorPemilik",
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Simpan data pembayaran atau lakukan aksi setelah pembayaran dikonfirmasi
                simpanDataPembayaran();
                // Tampilkan pesan konfirmasi
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text("Pembayaran Berhasil"),
                      content:
                          Text("Terima kasih! Pembayaran Anda telah berhasil."),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Tutup dialog
                            Navigator.pop(
                                context); // Kembali ke halaman sebelumnya
                          },
                          child: Text("OK"),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text("Konfirmasi Pembayaran"),
            ),
          ],
        ),
      ),
    );
  }

  void simpanDataPembayaran() {
    // Implementasi logika untuk menyimpan data pembayaran
    // Contoh: menyimpan ke database atau melakukan aksi lainnya
  }
}
