import 'package:flutter/material.dart';
import '../model/kost.dart';
import 'detail_kost.dart';

class KostUpdateForm extends StatefulWidget {
  final Kost kost;
  const KostUpdateForm({Key? key, required this.kost}) : super(key: key);

  @override
  _KostUpdateFormState createState() => _KostUpdateFormState();
}

class _KostUpdateFormState extends State<KostUpdateForm> {
  final _formKey = GlobalKey<FormState>();
  final _namaKostCtrl = TextEditingController();
  final _lokasiKostCtrl = TextEditingController();
  final _hargaKostCtrl = TextEditingController();
  final _fasilitasCtrl = TextEditingController();
  List<String> _fasilitasList = [];

  @override
  void initState() {
    super.initState();
    _namaKostCtrl.text = widget.kost.namaKost;
    _lokasiKostCtrl.text = widget.kost.lokasi;
    _hargaKostCtrl.text = widget.kost.harga.toString();
    _fasilitasList = List.from(widget.kost.fasilitas);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Ubah Kost")),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _fieldNamaKost(),
              _fieldLokasiKost(),
              _fieldHargaKost(),
              _fieldFasilitasKost(),
              const SizedBox(height: 20),
              _tombolSimpan(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldNamaKost() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        decoration: const InputDecoration(labelText: "Nama Kost"),
        controller: _namaKostCtrl,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Nama Kost tidak boleh kosong';
          }
          return null;
        },
      ),
    );
  }

  Widget _fieldLokasiKost() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        decoration: const InputDecoration(labelText: "Lokasi Kost"),
        controller: _lokasiKostCtrl,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Lokasi Kost tidak boleh kosong';
          }
          return null;
        },
      ),
    );
  }

  Widget _fieldHargaKost() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: TextFormField(
        decoration: const InputDecoration(labelText: "Harga Kost"),
        controller: _hargaKostCtrl,
        keyboardType: TextInputType.number,
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Harga Kost tidak boleh kosong';
          }
          if (double.tryParse(value) == null) {
            return 'Harga Kost harus berupa angka';
          }
          return null;
        },
      ),
    );
  }

  Widget _fieldFasilitasKost() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          TextFormField(
            decoration: const InputDecoration(labelText: "Fasilitas Kost"),
            controller: _fasilitasCtrl,
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              if (_fasilitasCtrl.text.isNotEmpty) {
                setState(() {
                  _fasilitasList.add(_fasilitasCtrl.text);
                  _fasilitasCtrl.clear();
                });
              }
            },
            child: const Text("Tambah Fasilitas"),
          ),
          const SizedBox(height: 10),
          Wrap(
            children: _fasilitasList.map((fasilitas) {
              return Chip(
                label: Text(fasilitas),
                onDeleted: () {
                  setState(() {
                    _fasilitasList.remove(fasilitas);
                  });
                },
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        if (_formKey.currentState!.validate()) {
          Kost updatedKost = Kost(
            id: widget.kost.id,
            namaKost: _namaKostCtrl.text,
            lokasi: _lokasiKostCtrl.text,
            harga: double.parse(_hargaKostCtrl.text),
            fasilitas: _fasilitasList,
          );
          // Simpan data yang telah diubah
          Navigator.pop(context);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => KostDetail(kost: updatedKost)),
          );
        }
      },
      child: const Text("Simpan Perubahan"),
    );
  }
}
