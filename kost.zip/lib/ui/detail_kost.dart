import 'package:flutter/material.dart';
import 'package:kost/ui/payment_method.dart';
import '../model/kost.dart';
import 'package:kost/ui/formulir_sewa.dart';

class KostDetail extends StatefulWidget {
  final Kost kost;

  const KostDetail({Key? key, required this.kost}) : super(key: key);

  @override
  State<KostDetail> createState() => _KostDetailState();
}

class _KostDetailState extends State<KostDetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Detail Kost")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Nama Kost: ${widget.kost.namaKost}",
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              "Lokasi: ${widget.kost.lokasi}",
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 10),
            Text(
              "Harga: Rp ${widget.kost.harga.toStringAsFixed(2)}",
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            const Text(
              "Fasilitas:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: widget.kost.fasilitas
                  .map((fasilitas) => Text("- $fasilitas"))
                  .toList(),
            ),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => FormulirSewa(kost: widget.kost),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                ),
                child: const Text("Sewa"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
