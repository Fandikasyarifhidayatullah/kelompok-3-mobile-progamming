import 'package:flutter/material.dart';
import '../model/kost.dart';
import '../model/penyewa.dart';
import 'kost_page.dart';

class SewaForm extends StatefulWidget {
  final Kost kost;
  const SewaForm({Key? key, required this.kost}) : super(key: key);

  @override
  State<SewaForm> createState() => _SewaFormState();
}

class _SewaFormState extends State<SewaForm> {
  final _formKey = GlobalKey<FormState>();
  final _namaPenyewaCtrl = TextEditingController();
  final _kontakPenyewaCtrl = TextEditingController();
  DateTime _tanggalSewa = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Form Penyewaan")),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _fieldNamaPenyewa(),
              _fieldKontakPenyewa(),
              _fieldTanggalSewa(),
              const SizedBox(height: 20),
              _tombolSimpan()
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldNamaPenyewa() {
    return TextFormField(
      decoration: const InputDecoration(labelText: "Nama Penyewa"),
      controller: _namaPenyewaCtrl,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Nama Penyewa tidak boleh kosong';
        }
        return null;
      },
    );
  }

  Widget _fieldKontakPenyewa() {
    return TextFormField(
      decoration: const InputDecoration(labelText: "Kontak Penyewa"),
      controller: _kontakPenyewaCtrl,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Kontak Penyewa tidak boleh kosong';
        }
        return null;
      },
    );
  }

  Widget _fieldTanggalSewa() {
    return ListTile(
      title: Text(
          "Tanggal Sewa: ${_tanggalSewa.day}-${_tanggalSewa.month}-${_tanggalSewa.year}"),
      trailing: Icon(Icons.calendar_today),
      onTap: () {
        _selectDate(context);
      },
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _tanggalSewa,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _tanggalSewa) {
      setState(() {
        _tanggalSewa = picked;
      });
    }
  }

  Widget _tombolSimpan() {
    return ElevatedButton(
      onPressed: () {
        if (_formKey.currentState!.validate()) {
          Penyewa penyewa = Penyewa(
            namaPenyewa: _namaPenyewaCtrl.text,
            kontak: _kontakPenyewaCtrl.text,
            tanggalSewa: _tanggalSewa,
          );
          // Simpan data penyewaan
          Navigator.pop(context);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const KostPage()),
          );
        }
      },
      child: const Text("Simpan Penyewaan"),
    );
  }
}
