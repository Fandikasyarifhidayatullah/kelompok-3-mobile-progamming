import 'package:flutter/material.dart';
import '../model/kost.dart';
import 'payment_confirmation.dart'; // Pastikan import ini benar

class PaymentMethod extends StatelessWidget {
  final Kost kost;

  const PaymentMethod({Key? key, required this.kost}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Metode Pembayaran")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Pilih Metode Pembayaran:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            PaymentOptionTile(
              title: "Transfer Bank",
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => BankPaymentOptions(kost: kost),
                  ),
                );
              },
            ),
            PaymentOptionTile(
              title: "Dompet Digital",
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => WalletPaymentOptions(kost: kost),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class BankPaymentOptions extends StatelessWidget {
  final Kost kost;

  const BankPaymentOptions({Key? key, required this.kost}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Transfer Bank")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Pilih Bank:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            PaymentOptionTile(
              title: "BCA",
              onTap: () {
                navigateToPaymentConfirmation(
                    context, 'Transfer Bank BCA', kost.nomorRekeningBCA);
              },
            ),
            PaymentOptionTile(
              title: "BNI",
              onTap: () {
                navigateToPaymentConfirmation(
                    context, 'Transfer Bank BNI', kost.nomorRekeningBNI);
              },
            ),
            PaymentOptionTile(
              title: "BRI",
              onTap: () {
                navigateToPaymentConfirmation(
                    context, 'Transfer Bank BRI', kost.nomorRekeningBRI);
              },
            ),
            PaymentOptionTile(
              title: "Mandiri",
              onTap: () {
                navigateToPaymentConfirmation(context, 'Transfer Bank Mandiri',
                    kost.nomorRekeningMandiri);
              },
            ),
          ],
        ),
      ),
    );
  }

  void navigateToPaymentConfirmation(
      BuildContext context, String method, String nomorPemilik) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PaymentConfirmation(
          kost: kost,
          method: method,
          nomorPemilik: nomorPemilik,
        ),
      ),
    );
  }
}

class WalletPaymentOptions extends StatelessWidget {
  final Kost kost;

  const WalletPaymentOptions({Key? key, required this.kost}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Dompet Digital")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Pilih Dompet Digital:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            PaymentOptionTile(
              title: "Dana",
              onTap: () {
                navigateToPaymentConfirmation(
                    context, 'Dana', kost.nomorDompetDigitalDana);
              },
            ),
            PaymentOptionTile(
              title: "OVO",
              onTap: () {
                navigateToPaymentConfirmation(
                    context, 'OVO', kost.nomorDompetDigitalOVO);
              },
            ),
            PaymentOptionTile(
              title: "GoPay",
              onTap: () {
                navigateToPaymentConfirmation(
                    context, 'GoPay', kost.nomorDompetDigitalGoPay);
              },
            ),
          ],
        ),
      ),
    );
  }

  void navigateToPaymentConfirmation(
      BuildContext context, String method, String nomorPemilik) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PaymentConfirmation(
          kost: kost,
          method: method,
          nomorPemilik: nomorPemilik,
        ),
      ),
    );
  }
}

class PaymentOptionTile extends StatelessWidget {
  final String title;
  final VoidCallback onTap;

  const PaymentOptionTile({
    Key? key,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(title),
      onTap: onTap,
    );
  }
}
