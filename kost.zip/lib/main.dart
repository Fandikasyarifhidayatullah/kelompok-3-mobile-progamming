import 'package:flutter/material.dart';
import 'ui/beranda.dart';
import 'ui/kost_page.dart';
import 'ui/kost_update_form.dart';
import 'ui/payment_confirmation.dart'; // Import file payment_confirmation.dart
import 'model/kost.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Kost default untuk digunakan dalam contoh ini
    Kost defaultKost = Kost(
      id: "default", // ID Kost
      namaKost: "Kost Default",
      lokasi: "Lokasi Default",
      harga: 0,
      fasilitas: [], // Daftar fasilitas kosong untuk contoh
    );

    return MaterialApp(
      title: 'Aplikasi Kost',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const Beranda(),
        '/daftar-kost': (context) => const KostPage(),
        '/tambah-kost': (context) => KostUpdateForm(
              kost: defaultKost, // Gunakan Kost default
            ),
        '/payment-confirmation': (context) => PaymentConfirmation(
              kost:
                  defaultKost, // Kirim Kost default ke halaman konfirmasi pembayaran
              method: 'Transfer Bank', // Contoh metode pembayaran
              nomorPemilik: '1234567890', // Tambahkan nomor pemilik
            ),
      },
    );
  }
}
