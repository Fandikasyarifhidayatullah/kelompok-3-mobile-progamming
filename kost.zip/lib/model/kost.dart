class Kost {
  String id;
  String namaKost;
  String lokasi;
  double harga;
  List<String> fasilitas;
  String nomorRekeningBCA;
  String nomorRekeningBNI;
  String nomorRekeningBRI;
  String nomorRekeningMandiri;
  String nomorDompetDigitalDana;
  String nomorDompetDigitalOVO;
  String nomorDompetDigitalGoPay;

  Kost({
    required this.id,
    required this.namaKost,
    required this.lokasi,
    required this.harga,
    required this.fasilitas,
    this.nomorRekeningBCA = '8960547186',
    this.nomorRekeningBNI = '8976640912',
    this.nomorRekeningBRI = '8971256378',
    this.nomorRekeningMandiri = '9873458274',
    this.nomorDompetDigitalDana = '0895336701727',
    this.nomorDompetDigitalOVO = '0895336801727',
    this.nomorDompetDigitalGoPay = '0895336801727',
  });
}
