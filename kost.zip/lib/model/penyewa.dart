class Penyewa {
  String? id;
  String namaPenyewa;
  String kontak;
  DateTime tanggalSewa;

  Penyewa({
    this.id,
    required this.namaPenyewa,
    required this.kontak,
    required this.tanggalSewa,
  });
}
